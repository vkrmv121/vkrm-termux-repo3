// SPDX-FileCopyrightText: 2011 Mathieu Desnoyers <mathieu.desnoyers@efficios.com>
//
// SPDX-License-Identifier: LGPL-2.1-or-later

#warning "urcu/urcu_ref.h is deprecated. Please include urcu/ref.h instead."
#include <urcu/ref.h>
