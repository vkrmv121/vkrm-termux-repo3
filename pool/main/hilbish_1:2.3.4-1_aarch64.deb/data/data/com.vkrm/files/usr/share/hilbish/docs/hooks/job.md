Note: `job` refers to a job object. You can check `doc jobs` for more
detail.

+ `job.start` -> job > Thrown when a new background job starts.

+ `job.done` -> job > Thrown when a background jobs exits.

