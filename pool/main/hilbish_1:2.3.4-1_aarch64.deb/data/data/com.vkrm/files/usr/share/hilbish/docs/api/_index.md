---
title: API
layout: doc
weight: -100
menu: docs
---

Welcome to the API documentation for Hilbish. This documents Lua functions
provided by Hilbish.
