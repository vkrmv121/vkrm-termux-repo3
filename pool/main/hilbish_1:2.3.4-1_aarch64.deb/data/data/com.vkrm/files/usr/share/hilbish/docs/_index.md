---
title: Introduction
layout: doc
weight: -1
menu: docs
---

Hilbish is a hyper-extensible shell mainly intended for interactive use.
To enhance the interactive experience, Hilbish comes with a wide range
of features and sane defaults, including a nice looking prompt,
advanced completion menus and history search.

Here documents some of the features of Hilbish and the Lua API.
