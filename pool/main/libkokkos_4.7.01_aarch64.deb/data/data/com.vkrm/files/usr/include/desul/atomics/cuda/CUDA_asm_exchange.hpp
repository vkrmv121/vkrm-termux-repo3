#include <limits>
namespace desul {
namespace Impl {
#include <desul/atomics/cuda/cuda_cc7_asm_exchange.inc>
}
}  // namespace desul
