#ifndef GEO_CONFIG_H
#define GEO_CONFIG_H

/* Define if you have the <strings.h> header file.  */
#define GEOTIFF_HAVE_STRINGS_H 1

/* #undef GEO_NORMALIZE_DISABLE_TOWGS84 */

#endif /* ndef GEO_CONFIG_H */
