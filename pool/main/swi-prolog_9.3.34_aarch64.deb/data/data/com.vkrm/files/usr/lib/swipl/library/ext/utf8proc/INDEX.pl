/*  Creator: make/0

    Purpose: Provide index for autoload
*/

index(unicode_property(?,?), unicode, unicode).
index(unicode_map(?,?,?), unicode, unicode).
index(unicode_nfd(?,?), unicode, unicode).
index(unicode_nfc(?,?), unicode, unicode).
index(unicode_nfkd(?,?), unicode, unicode).
index(unicode_nfkc(?,?), unicode, unicode).
