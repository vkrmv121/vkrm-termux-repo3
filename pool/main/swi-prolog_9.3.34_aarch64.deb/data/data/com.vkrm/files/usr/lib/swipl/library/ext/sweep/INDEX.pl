/*  Creator: make/0

    Purpose: Provide index for autoload
*/

index(write_sweep_module_location, sweep_link, sweep_link).
