/*  Creator: make/0

    Purpose: Provide index for autoload
*/

index(zopen(?,?,?), zlib, zlib).
index(gzopen(?,?,?), zlib, zlib).
index(gzopen(?,?,?,?), zlib, zlib).
