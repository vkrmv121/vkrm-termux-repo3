# Allow for both `import janus` and `import janus_swi` if Python is embedded
# into Prolog.

from janus import *
