/*  Creator: make/0

    Purpose: Provide index for autoload
*/

index(mqi_start, mqi, mqi).
index(mqi_start(?), mqi, mqi).
index(mqi_stop(?), mqi, mqi).
index(mqi_version(?,?), mqi, mqi).
