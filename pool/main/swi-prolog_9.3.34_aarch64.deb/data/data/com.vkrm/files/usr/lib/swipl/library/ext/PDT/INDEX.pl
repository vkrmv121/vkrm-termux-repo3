/*  Creator: make/0

    Purpose: Provide index for autoload
*/

index(pdt_install_console, pdt_console, pdt_console).
