##
## This script is sourced by /data/data/com.vkrm/files/usr/bin/login before executing shell.
##
