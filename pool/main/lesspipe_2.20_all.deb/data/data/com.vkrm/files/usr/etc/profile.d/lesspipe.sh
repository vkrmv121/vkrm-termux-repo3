export LESSOPEN='|/data/data/com.vkrm/files/usr/bin/lesspipe.sh %s'
