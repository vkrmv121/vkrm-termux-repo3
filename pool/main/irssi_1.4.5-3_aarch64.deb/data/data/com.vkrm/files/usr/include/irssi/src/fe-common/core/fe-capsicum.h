#ifndef IRSSI_FE_COMMON_CORE_FE_CAPSICUM_H
#define IRSSI_FE_COMMON_CORE_FE_CAPSICUM_H

void fe_capsicum_init(void);
void fe_capsicum_deinit(void);

#endif
