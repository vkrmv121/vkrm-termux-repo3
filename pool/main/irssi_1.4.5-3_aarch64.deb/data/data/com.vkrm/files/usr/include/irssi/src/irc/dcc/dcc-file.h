#ifndef IRSSI_IRC_DCC_DCC_FILE_H
#define IRSSI_IRC_DCC_DCC_FILE_H

#include <irssi/src/irc/dcc/dcc.h>

typedef struct {
#include <irssi/src/irc/dcc/dcc-file-rec.h>
} FILE_DCC_REC;

#endif
