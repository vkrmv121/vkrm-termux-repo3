#ifndef IRSSI_IRC_CORE_CHANNEL_EVENTS_H
#define IRSSI_IRC_CORE_CHANNEL_EVENTS_H

#include <irssi/src/irc/core/irc.h>

void channel_events_init(void);
void channel_events_deinit(void);

#endif
