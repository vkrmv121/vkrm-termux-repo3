<!--
SPDX-FileCopyrightText: Peter Pentchev <roam@ringlet.net>
SPDX-License-Identifier: BSD-2-Clause
-->

# Download

These are the released versions of [hexer](index.md) available for download.

## [1.0.7] - 2025-08-17

### Source tarball

- [hexer-1.0.7.tar.gz](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.7.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.7.tar.gz.asc))
- [hexer-1.0.7.tar.bz2](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.7.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.7.tar.bz2.asc))
- [hexer-1.0.7.tar.xz](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.7.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.7.tar.xz.asc))

## [1.0.6] - 2020-04-24

### Source tarball

- [hexer-1.0.6.tar.gz](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.6.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.6.tar.gz.asc))
- [hexer-1.0.6.tar.bz2](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.6.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.6.tar.bz2.asc))
- [hexer-1.0.6.tar.xz](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.6.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.6.tar.xz.asc))

## [1.0.5] - 2018-09-22

### Source tarball

- [hexer-1.0.5.tar.gz](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.5.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.5.tar.gz.asc))
- [hexer-1.0.5.tar.bz2](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.5.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.5.tar.bz2.asc))
- [hexer-1.0.5.tar.xz](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.5.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.5.tar.xz.asc))

## [1.0.4] - 2018-03-24

### Source tarball

- [hexer-1.0.4.tar.gz](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.4.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.4.tar.gz.asc))
- [hexer-1.0.4.tar.bz2](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.4.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.4.tar.bz2.asc))
- [hexer-1.0.4.tar.xz](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.4.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.4.tar.xz.asc))

## [1.0.3] - 2016-10-16

### Source tarball

- [hexer-1.0.3.tar.gz](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.3.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.3.tar.gz.asc))
- [hexer-1.0.3.tar.bz2](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.3.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.3.tar.bz2.asc))
- [hexer-1.0.3.tar.xz](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.3.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.3.tar.xz.asc))

## [1.0.2] - 2016-10-13

### Source tarball

- [hexer-1.0.2.tar.gz](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.2.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.2.tar.gz.asc))
- [hexer-1.0.2.tar.bz2](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.2.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.2.tar.bz2.asc))
- [hexer-1.0.2.tar.xz](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.2.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.2.tar.xz.asc))

## [1.0.1] - 2016-10-12

### Source tarball

- [hexer-1.0.1.tar.gz](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.1.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.1.tar.gz.asc))
- [hexer-1.0.1.tar.bz2](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.1.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.1.tar.bz2.asc))
- [hexer-1.0.1.tar.xz](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.1.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.1.tar.xz.asc))

## [1.0.0] - 2016-10-12

### Source tarball

- [hexer-1.0.0.tar.gz](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.0.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.0.tar.gz.asc))
- [hexer-1.0.0.tar.bz2](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.0.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.0.tar.bz2.asc))
- [hexer-1.0.0.tar.xz](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.0.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-1.0.0.tar.xz.asc))

## [0.2.3] - 2015-12-10

### Source tarball

- [hexer-0.2.3.tar.gz](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.3.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.3.tar.gz.asc))
- [hexer-0.2.3.tar.bz2](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.3.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.3.tar.bz2.asc))
- [hexer-0.2.3.tar.xz](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.3.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.3.tar.xz.asc))

## [0.2.2] - 2015-12-10

### Source tarball

- [hexer-0.2.2.tar.gz](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.2.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.2.tar.gz.asc))
- [hexer-0.2.2.tar.bz2](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.2.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.2.tar.bz2.asc))
- [hexer-0.2.2.tar.xz](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.2.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.2.tar.xz.asc))

## [0.2.1] - 2015-12-10

### Source tarball

- [hexer-0.2.1.tar.gz](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.1.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.1.tar.gz.asc))
- [hexer-0.2.1.tar.bz2](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.1.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.1.tar.bz2.asc))
- [hexer-0.2.1.tar.xz](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.1.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.1.tar.xz.asc))

## [0.2.0] - 2015-12-09

### Source tarball

- [hexer-0.2.0.tar.gz](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.0.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.0.tar.gz.asc))
- [hexer-0.2.0.tar.bz2](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.0.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.0.tar.bz2.asc))
- [hexer-0.2.0.tar.xz](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.0.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.2.0.tar.xz.asc))

## [0.1.8] - 2014-09-11

### Source tarball

- [hexer-0.1.8.tar.gz](https://devel.ringlet.net/files/editors/hexer/hexer-0.1.8.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.1.8.tar.gz.asc))
- [hexer-0.1.8.tar.bz2](https://devel.ringlet.net/files/editors/hexer/hexer-0.1.8.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.1.8.tar.bz2.asc))
- [hexer-0.1.8.tar.xz](https://devel.ringlet.net/files/editors/hexer/hexer-0.1.8.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.1.8.tar.xz.asc))

## [0.1.7] - 2011-07-13

### Source tarball

- [hexer-0.1.7.tar.gz](https://devel.ringlet.net/files/editors/hexer/hexer-0.1.7.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.1.7.tar.gz.asc))
- [hexer-0.1.7.tar.bz2](https://devel.ringlet.net/files/editors/hexer/hexer-0.1.7.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.1.7.tar.bz2.asc))

## [0.1.6] - 2010-12-29

### Source tarball

- [hexer-0.1.6.tar.gz](https://devel.ringlet.net/files/editors/hexer/hexer-0.1.6.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.1.6.tar.gz.asc))
- [hexer-0.1.6.tar.bz2](https://devel.ringlet.net/files/editors/hexer/hexer-0.1.6.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.1.6.tar.bz2.asc))

## [0.1.5] - 2009-09-04

### Source tarball

- [hexer-0.1.5.tar.gz](https://devel.ringlet.net/files/editors/hexer/hexer-0.1.5.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/editors/hexer/hexer-0.1.5.tar.gz.asc))

## [0.1.4c]

### Source tarball

- [hexer-0.1.4c.tar.gz](https://devel.ringlet.net/files/editors/hexer/hexer-0.1.4c.tar.gz)

[1.0.7]: https://gitlab.com/hexer/hexer/-/tags/release%2F1.0.7
[1.0.6]: https://gitlab.com/hexer/hexer/-/tags/release%2F1.0.6
[1.0.5]: https://gitlab.com/hexer/hexer/-/tags/release%2F1.0.5
[1.0.4]: https://gitlab.com/hexer/hexer/-/tags/release%2F1.0.4
[1.0.3]: https://gitlab.com/hexer/hexer/-/tags/release%2F1.0.3
[1.0.2]: https://gitlab.com/hexer/hexer/-/tags/release%2F1.0.2
[1.0.1]: https://gitlab.com/hexer/hexer/-/tags/release%2F1.0.1
[1.0.0]: https://gitlab.com/hexer/hexer/-/tags/release%2F1.0.0
[0.2.3]: https://gitlab.com/hexer/hexer/-/tags/release%2F0.2.3
[0.2.2]: https://gitlab.com/hexer/hexer/-/tags/release%2F0.2.2
[0.2.1]: https://gitlab.com/hexer/hexer/-/tags/release%2F0.2.1
[0.2.0]: https://gitlab.com/hexer/hexer/-/tags/release%2F0.2.0
[0.1.8]: https://gitlab.com/hexer/hexer/-/tags/release%2F0.1.8
[0.1.7]: https://gitlab.com/hexer/hexer/-/tags/release%2F0.1.7
[0.1.6]: https://gitlab.com/hexer/hexer/-/tags/release%2F0.1.6
[0.1.5]: https://gitlab.com/hexer/hexer/-/tags/release%2F0.1.5
[0.1.4c]: https://gitlab.com/hexer/hexer/-/tags/release%2F0.1.4c
